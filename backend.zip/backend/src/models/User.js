// const mongoose = require("mongoose");

// const userSchema = new mongoose.Schema(
//   {
//     name: { type: String, required: true },
//     email: { type: String, required: true, unique: true },
//     password: { type: String, required: true },
//   },
//   { timestamps: true }
// );

// module.exports = mongoose.model("User", userSchema);
// backend/models/User.js
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },

    // ✅ Profile-related fields
    preferences: {
      goals: [{ type: String }], // e.g. ["Lose Weight", "Gain Muscle"]
      activityLevel: { type: String }, // e.g. "Moderately Active"
      dietaryPreference: { type: String }, // e.g. "Vegan"
      allergies: [{ type: String }], // e.g. ["Gluten", "Dairy"]
      cookingTime: { type: String }, // e.g. "Under 30 min"
      skillLevel: { type: String }, // e.g. "Beginner"
    },

    dietaryRestrictions: [{ type: String }], // extra restrictions if you want
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);

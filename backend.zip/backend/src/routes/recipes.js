const express = require("express");
const router = express.Router();
require("dotenv").config();
const { GoogleGenerativeAI } = require("@google/generative-ai");

// ✅ Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

// POST /api/recipes/suggest
router.post("/suggest", async (req, res) => {
  try {
    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).json({ message: "Prompt is required" });
    }

    // ✅ Call Gemini
    const result = await model.generateContent(prompt);

    // Extract text response
    const text = result.response.text();

    // Convert Gemini text into an array of recipes (split by line or number)
    const recipes = text
      .split(/\n|\d+\./) // split on new lines or "1."
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    res.json({ recipes });
  } catch (err) {
    console.error("❌ Gemini error:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;

// backend/routes/profile.js
const express = require("express");
const User = require("../models/User");
const router = express.Router();

/**
 * @route   POST /api/profile/save
 * @desc    Save or update user profile
 */
router.post("/save", async (req, res) => {
  try {
    const {
      userId,
      goals,
      activityLevel,
      dietaryPreference,
      preferences,
      dietaryRestrictions,
      allergies,
      cookingTime,
      skillLevel,
    } = req.body;

    if (!userId) {
      return res.status(400).json({ message: "❌ userId is required" });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "❌ User not found" });
    }

    // ✅ Save profile fields
    user.goals = goals || user.goals;
    user.activityLevel = activityLevel || user.activityLevel;
    user.dietaryPreference = dietaryPreference || user.dietaryPreference;
    user.preferences = preferences || user.preferences;
    user.dietaryRestrictions = dietaryRestrictions || user.dietaryRestrictions;
    user.allergies = allergies || user.allergies;
    user.cookingTime = cookingTime || user.cookingTime;
    user.skillLevel = skillLevel || user.skillLevel;

    await user.save();

    res.json({ message: "✅ Profile saved successfully", user });
  } catch (err) {
    console.error("❌ Error saving profile:", err.message);
    res.status(500).json({ message: "❌ Server error", error: err.message });
  }
});

/**
 * @route   GET /api/profile/:userId
 * @desc    Fetch user profile
 */
router.get("/:userId", async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select(
      "email goals activityLevel dietaryPreference preferences dietaryRestrictions allergies cookingTime skillLevel"
    );

    if (!user) {
      return res.status(404).json({ message: "❌ User not found" });
    }

    res.json(user);
  } catch (err) {
    console.error("❌ Error fetching profile:", err.message);
    res.status(500).json({ message: "❌ Server error", error: err.message });
  }
});

module.exports = router;

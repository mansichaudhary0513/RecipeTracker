// import React, { useEffect, useState } from "react";
// import "./SuggestRecipe.css"; // 👈 import css

// const SuggestRecipe = () => {
//   const [recipes, setRecipes] = useState([]);
//   const [loading, setLoading] = useState(false);

//   const fetchRecipes = async () => {
//     setLoading(true);
//     try {
//       const res = await fetch("http://localhost:5000/api/recipes/suggest");
//       const data = await res.json();
//       setRecipes(data.recipes || []);
//     } catch (err) {
//       console.error(err);
//     }
//     setLoading(false);
//   };

//   useEffect(() => {
//     fetchRecipes();
//   }, []);

//   return (
//     <div className="suggest-container">
//       <h1 className="suggest-title">🍲 Suggested Recipes</h1>

//       {loading ? (
//         <p>Loading recipes...</p>
//       ) : (
//         <div className="recipes-grid">
//           {recipes.map((recipe, index) => (
//             <div key={index} className="recipe-card">
//               <h2 className="recipe-title">{recipe.title}</h2>
//               <p className="recipe-description">{recipe.description}</p>
//               {recipe.ingredients && (
//                 <ul className="recipe-ingredients">
//                   {recipe.ingredients.map((ing, i) => (
//                     <li key={i}>{ing}</li>
//                   ))}
//                 </ul>
//               )}
//             </div>
//           ))}
//         </div>
//       )}

//       <button className="refresh-btn" onClick={fetchRecipes}>
//         🔄 Refresh Recipes
//       </button>
//     </div>
//   );
// };

// export default SuggestRecipe;
import React, { useEffect, useState } from "react";

const SuggestRecipe = () => {
  const [profile, setProfile] = useState(null);
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const userId = localStorage.getItem("userId");
        if (!userId) {
          alert("❌ No user logged in!");
          setLoading(false);
          return;
        }

        // ✅ fetch profile from backend
        const res = await fetch(`http://localhost:5000/api/profile/${userId}`);
        const data = await res.json();

        if (res.ok) {
          console.log("✅ Profile fetched:", data);
          setProfile(data);
          // now call Gemini
          fetchRecipes(data);
        } else {
          alert(`❌ Error fetching profile: ${data.message}`);
          setLoading(false);
        }
      } catch (err) {
        console.error("Error fetching profile:", err);
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  // ✅ call Gemini API with profile
  const fetchRecipes = async (profileData) => {
    try {
      const prompt = `
        Suggest 5 personalized recipes based on this profile:
        Goals: ${profileData.preferences?.goals?.join(", ")}
        Activity Level: ${profileData.preferences?.activityLevel}
        Dietary Preference: ${profileData.preferences?.dietaryPreference}
        Allergies: ${profileData.preferences?.allergies?.join(", ")}
        Cooking Time: ${profileData.preferences?.cookingTime}
        Skill Level: ${profileData.preferences?.skillLevel}
      `;

      const res = await fetch("http://localhost:5000/api/recipes/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });

      const data = await res.json();
      if (res.ok) {
        console.log("✅ Recipes:", data);
        setRecipes(data.recipes || []);
      } else {
        alert(`❌ Error fetching recipes: ${data.message}`);
      }
    } catch (err) {
      console.error("Error fetching recipes:", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <p>⏳ Loading suggestions...</p>;

  return (
    <div className="suggest-container">
      <h2>🍽 Personalized Recipe Suggestions</h2>

      {profile && (
        <div className="profile-summary">
          <h3>Your Profile</h3>
          <p>
            <strong>Goals:</strong> {profile.preferences?.goals?.join(", ")}
          </p>
          <p>
            <strong>Activity Level:</strong>{" "}
            {profile.preferences?.activityLevel}
          </p>
          <p>
            <strong>Diet:</strong> {profile.preferences?.dietaryPreference}
          </p>
          <p>
            <strong>Allergies:</strong>{" "}
            {profile.preferences?.allergies?.join(", ")}
          </p>
          <p>
            <strong>Cooking Time:</strong> {profile.preferences?.cookingTime}
          </p>
          <p>
            <strong>Skill Level:</strong> {profile.preferences?.skillLevel}
          </p>
        </div>
      )}

      <div className="recipes">
        <h3>Suggested Recipes</h3>
        {recipes.length > 0 ? (
          <ul>
            {recipes.map((recipe, idx) => (
              <li key={idx}>{recipe}</li>
            ))}
          </ul>
        ) : (
          <p>No recipes found.</p>
        )}
      </div>
    </div>
  );
};

export default SuggestRecipe;

const mongoose = require("mongoose");

const profileSchema = new mongoose.Schema({
  age: { type: Number, required: true },
  weight: { type: Number, required: true },
  height: { type: Number, required: true },
  dietType: { type: String, enum: ["veg", "non-veg"], required: true },
});

module.exports = mongoose.model("Profile", profileSchema);

// import React from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import "./App.css";

// // Components
// import Navbar from "./components/Navbar";
// import Hero from "./components/Hero";
// import Features from "./components/Features";
// import GeminiFeature from "./components/GeminiFeature";
// import Footer from "./components/Footer";
// import Signup from "./components/Signup";
// import Login from "./components/Login"; // ✅ correct
// import ProfileForm from "./components/ProfileForm"; // ✅ correct

// const LandingPage = () => (
//   <>
//     <Hero />
//     <Features />
//     <GeminiFeature />
//     <Footer />
//   </>
// );

// function App() {
//   return (
//     <Router>
//       <div className="App">
//         <Navbar />
//         <Routes>
//           <Route path="/" element={<LandingPage />} />
//           <Route path="/signup" element={<Signup />} />
//           <Route path="/login" element={<Login />} />
//           <Route path="/profile" element={<ProfileForm />} />
//         </Routes>
//       </div>
//     </Router>
//   );
// }

// export default App;
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";

// Components
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import GeminiFeature from "./components/GeminiFeature";
import Footer from "./components/Footer";
import Signup from "./components/Signup";
import Login from "./components/Login";
import ProfileForm from "./components/ProfileForm";
import SuggestRecipe from "./components/SuggestRecipe";

// Landing page (home)
const LandingPage = () => (
  <>
    <Hero />
    <Features />
    <GeminiFeature />
    <Footer />
  </>
);

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/profile" element={<ProfileForm />} />
          <Route path="/recipes" element={<SuggestRecipe />} /> ✅ new route
          <Route path="/suggest" element={<SuggestRecipe />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
